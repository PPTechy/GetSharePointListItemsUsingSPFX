import { Version } from '@microsoft/sp-core-library';
import { IPropertyPaneConfiguration } from '@microsoft/sp-property-pane';
import { BaseClientSideWebPart } from '@microsoft/sp-webpart-base';
export interface IReadSpListItemsWebPartProps {
    description: string;
}
export interface ISPLists {
    value: ISPList[];
}
export interface ISPList {
    Title: string;
    CustomerID: string;
    CustomerContactNo: string;
}
export default class ReadSpListItemsWebPart extends BaseClientSideWebPart<IReadSpListItemsWebPartProps> {
    private _getListData;
    private _renderListAsync;
    private _renderList;
    render(): void;
    protected readonly dataVersion: Version;
    protected getPropertyPaneConfiguration(): IPropertyPaneConfiguration;
}
//# sourceMappingURL=ReadSpListItemsWebPart.d.ts.map