/* tslint:disable */
require("./ReadSpListItemsWebPart.module.css");
const styles = {
  readSpListItems: 'readSpListItems_3ee49a43',
  container: 'container_3ee49a43',
  row: 'row_3ee49a43',
  column: 'column_3ee49a43',
  'ms-Grid': 'ms-Grid_3ee49a43',
  title: 'title_3ee49a43',
  subTitle: 'subTitle_3ee49a43',
  description: 'description_3ee49a43',
  button: 'button_3ee49a43',
  label: 'label_3ee49a43'
};

export default styles;
/* tslint:enable */