declare interface IReadSpListItemsWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
}

declare module 'ReadSpListItemsWebPartStrings' {
  const strings: IReadSpListItemsWebPartStrings;
  export = strings;
}
